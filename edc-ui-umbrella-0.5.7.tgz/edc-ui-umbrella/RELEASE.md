# Connector Helm Charts - Release Guide

## 1. Docker Image Tag Release (Automated)

### EDC Controlplane & Dataplane

1. Create a new Git tag on the EDC repository.
2. The CI pipeline automatically:
   - Builds and pushes Docker images to **ACR** and **DockerHub**.
   - Updates `appVersion` in the Connector Helm Chart:
     - **Repo:** [app-pia-connector-ui](https://github.com/SEGITTURPIDPIA/app-pia-connector-ui)
     - **Path:** `charts/tractusx-connector/Chart.yaml`

### EDC UI

1. Create a new Git tag on the EDC UI repository.
2. The CI pipeline automatically:
   - Builds and pushes Docker images to **ACR** and **DockerHub**.
   - Updates `appVersion` in the Connector UI Helm Chart:
     - **Repo:** [app-pia-connector-ui](https://github.com/SEGITTURPIDPIA/app-pia-connector-ui)
     - **Path:** `charts/app-pia-connector-ui/Chart.yaml`

---

## 2. Umbrella Chart Release (Manual)

Once the image tags are updated, follow the steps below to release the umbrella chart for both **SaaS** and **On-Prem** connectors.

### Step 1 — Update Umbrella Chart Values (SaaS)

If there are any changes in the umbrella chart values (EDC + EDC-UI), update them in:

- **Umbrella `values.yaml`:**
  [`charts/edc-ui-umbrella/values.yaml`](https://github.com/SEGITTURPIDPIA/app-pia-connector-ui/blob/main/charts/edc-ui-umbrella/values.yaml)

- **Managed Service Orchestrator:**
  Update the corresponding values template in the [tractusx-managed-service-orchestrator](https://github.com/SEGITTURPIDPIA/tractusx-managed-service-orchestrator) repository.

### Step 2 — Update Example Values (On-Prem)

Apply the same value changes to the on-prem example values file:

- [`charts/edc-ui-umbrella/examples/onprem-edc-values.yaml`](https://github.com/SEGITTURPIDPIA/app-pia-connector-ui/blob/main/charts/edc-ui-umbrella/examples/onprem-edc-values.yaml)

### Step 3 — Bump Helm Chart Version

Update `version` in the umbrella Chart.yaml to release the new chart:

- [`charts/edc-ui-umbrella/Chart.yaml`](https://github.com/SEGITTURPIDPIA/app-pia-connector-ui/blob/main/charts/edc-ui-umbrella/Chart.yaml)

> **Note:** Use strict SemVer (`MAJOR.MINOR.PATCH`) for the chart version. Pre-release suffixes (e.g., `0.5.4-patch.9`) will not appear in `helm search repo` unless `--devel` is passed.

### Step 4 — Merge to `main`

Push the changes to `main`. The GitHub Pages CI will rebuild the Helm repo index and publish the new chart version.

---

## Summary

| What | How | Scope |
|---|---|---|
| EDC image tags | Automated via Git tag on EDC repo | ACR, DockerHub, `tractusx-connector/Chart.yaml` |
| UI image tags | Automated via Git tag on UI repo | ACR, DockerHub, `app-pia-connector-ui/Chart.yaml` |
| Umbrella values (SaaS) | Manual update in `edc-ui-umbrella/values.yaml` + Orchestrator | SaaS connectors |
| Umbrella values (On-Prem) | Manual update in `examples/onprem-edc-values.yaml` | On-Prem connectors |
| Chart version bump | Manual update in `edc-ui-umbrella/Chart.yaml` | Helm repo release |

This ensures the latest EDC tags and value templates are released simultaneously for both SaaS and On-Prem connectors.
